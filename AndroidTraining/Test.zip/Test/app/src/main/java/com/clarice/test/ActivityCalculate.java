package com.clarice.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.EditText;

/**
 * Created by jayeshvarma on 27/1/15.
 */
public class ActivityCalculate extends ActionBarActivity {

    int result;
    EditText a, b;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate);
        a = (EditText) findViewById(R.id.edittext_a);
        b = (EditText) findViewById(R.id.edittext_b);

        findViewById(R.id.button_done).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int val = Integer.valueOf(a.getText().toString());
                int val1 = Integer.valueOf(b.getText().toString());
                result = val + val1;
                Intent intenttotal =  new Intent();
                intenttotal.putExtra("result", String.valueOf(result));
                setResult(Activity.RESULT_OK, intenttotal);
                finish();
            }
        });
    }
}
