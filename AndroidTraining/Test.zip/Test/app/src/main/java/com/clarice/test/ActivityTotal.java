package com.clarice.test;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by jayeshvarma on 27/1/15.
 */
public class ActivityTotal extends ActionBarActivity {

    private EditText mTotal;
    static final int PICK_TOTAL_REQUEST = 1;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activiity_total);
        TextView mName = (TextView) findViewById(R.id.set_name);
        mTotal = (EditText) findViewById(R.id.total_cal);

        //set name
        mName.setText(getIntent().getExtras().getString("name").toString());
        // button click
        findViewById(R.id.button_get_result).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ActivityTotal.this, ActivityCalculate.class);
                startActivityForResult(intent, PICK_TOTAL_REQUEST);
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        mTotal.setText("hello");
        if ((requestCode == PICK_TOTAL_REQUEST) && (resultCode == RESULT_OK)){
                mTotal.setText(data.getStringExtra("result"));
//            mTotal.setText("hello");
        }

    }
}
