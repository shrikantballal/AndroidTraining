package com.clarice.listviewexample;

import android.content.Context;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class MainActivity extends ActionBarActivity {

    ArrayList<RandomData> mArrayList = new ArrayList<RandomData>();
    TempListAdapter adapter = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = (ListView) findViewById(R.id.listView);

        createRandomData();

        adapter = new TempListAdapter(this);
        listView.setAdapter(adapter);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            createRandomData();
            adapter.notifyDataSetChanged();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void createRandomData () {
        RandomData data = null;
        for(int i = 0; i<20; i++) {
            data = new RandomData();
            data.setTitle("Title " + i);
            data.setDesc("Description " + i);
            mArrayList.add(data);
        }
    }

    class RandomData {
        String title, desc;
        boolean isLToR;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }
    }

    class TempListAdapter extends BaseAdapter
    {
        ViewHolder mViewHolder;
        LayoutInflater mLayoutInflater;

        public TempListAdapter(Context context) {
            mLayoutInflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        @Override
        public int getCount() {
            return mArrayList.size();
        }

        @Override
        public RandomData getItem(int position) {
            return mArrayList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView == null) {
                mViewHolder = new ViewHolder();
                convertView = mLayoutInflater.inflate(R.layout.list_row, null);
                mViewHolder.title = (TextView) convertView.findViewById(R.id.titleTV);
                mViewHolder.desc = (TextView) convertView.findViewById(R.id.descTV);
                convertView.setTag(mViewHolder);
            } else {
                mViewHolder = (ViewHolder)convertView.getTag();
            }
            mViewHolder.title.setText(getItem(position).getTitle());
            mViewHolder.desc.setText(getItem(position).getDesc());
            return convertView;
        }

        class ViewHolder {
            TextView title, desc;
        }
    }
}
